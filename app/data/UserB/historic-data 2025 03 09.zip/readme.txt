Arduino Cloud historic data

variables:
  - id: f9258eb1-8317-4baf-ad8b-b63aeb6f582e
    name: Accelerometer_X
    thingName: Pixel 8 Pro Thing
  - id: e0d2b5a1-cd30-48fc-b3fd-82c195319353
    name: Accelerometer_Y
    thingName: Pixel 8 Pro Thing
  - id: 60616fbd-9373-4236-81c8-15eee3a141e4
    name: Accelerometer_Z
    thingName: Pixel 8 Pro Thing
  - id: fbaeb6b2-420e-4a89-a719-4efe46984b73
    name: Gps
    thingName: Pixel 8 Pro Thing
  - id: 6b419129-5465-498d-b5ee-fa3b63ee3cfd
    name: Accelerometer_Linear
    thingName: Pixel 8 Pro Thing
from: 2025-03-08T04:27:45Z
to: 2025-03-09T23:59:59Z

Have fun! :)
